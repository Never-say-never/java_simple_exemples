/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.testspringapp.repositories;

import com.testspringapp.entities.TestUsers;
import org.springframework.data.repository.CrudRepository;   
import org.springframework.stereotype.Repository;

/**
 *
 * @author java-monkey
 */

@Repository
public interface UsersRepository extends CrudRepository<TestUsers, Long> {
    
    public abstract TestUsers findByUsername(String username);
    
}