/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.testspringapp.controllers;

import com.testspringapp.entities.DefaultActions;
import com.testspringapp.entities.TestUsers;
import com.testspringapp.repositories.DefaultActionsRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.testspringapp.repositories.UsersRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author java-monkey
 */

@Controller
public class DefaultController {
    
    @Autowired
    private UsersRepository users;
    
    @Autowired
    private DefaultActionsRepository actions;
    
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index(ModelMap map) {
        List<TestUsers> result = new ArrayList<>();
        for(TestUsers user : users.findAll()){
            result.add(user);
        }
        
        String message = "Empty user list";
        if(!result.isEmpty()){
            message = Arrays.toString(result.toArray());
        }

        ArrayList<String> actionList = this.initActionItems();
        if(actionList.isEmpty()){
            ArrayList warning = new ArrayList<>();
            warning.add("Actions does not initialysed!");
            map.put("actions", warning);
        }
        
        map.put("actions", actionList);
        map.put("msg", "Hello " + message);
        
        return "index";
    }
    
    private ArrayList<String> initActionItems(){
        ArrayList<String> actionList = new ArrayList<>();
        for(DefaultActions action : this.actions.findAll()){
            actionList.add(action.toString());
        }
        
        return actionList;
    }
    
}
