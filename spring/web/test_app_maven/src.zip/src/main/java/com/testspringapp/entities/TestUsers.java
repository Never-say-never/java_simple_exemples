/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.testspringapp.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 *
 * @author java-monkey
 */

@Entity
@Table(name="TestUsers")
public class TestUsers implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    
    private String username;
    
    private String password;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUser() {
        return username;
    }

    public void setUser(String user) {
        this.username = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public TestUsers(String username, String password){
        this.password = password;
        this.username = username;
    }
    
    protected TestUsers(){}
    
    @Override
    public String toString(){
        return this.username;
    }
}
